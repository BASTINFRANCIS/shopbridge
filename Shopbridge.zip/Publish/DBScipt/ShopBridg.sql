USE MASTER
GO
CREATE DATABASE ShopBridge
GO
USE ShopBridge
GO
CREATE TABLE [dbo].[Product](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProductCode] [varchar](100) NOT NULL,
	[ProductName] [nvarchar](100) NULL,
	[Description] [nvarchar](500) NULL,
	[Price] [decimal](10, 2) NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](100) NULL,
	[UpdatedBy] [varchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE PROC [dbo].[sp_SaveProduct]
(
@ProductCode VARCHAR(100),
@ProductName NVARCHAR(100),
@Description NVARCHAR(500),
@Price DECIMAL(10,2),
@User VARCHAR(100) = '',
@Mode VARCHAR(10)
)
AS
BEGIN
	IF @Mode = 'ADD'
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM Product WHERE ProductCode = @ProductCode)
		BEGIN
			INSERT INTO Product(ProductCode,ProductName,[Description],Price,CreatedDate,CreatedBy)
			VALUES(@ProductCode,@ProductName,@Description,@Price,GETUTCDATE(),@User)
		END
	END
	ELSE IF @Mode = 'UPDATE'
	BEGIN
		UPDATE Product SET ProductName = @ProductName,[Description] = @Description,
		Price = @Price,UpdatedDate = GETUTCDATE(),UpdatedBy = @User
		WHERE ProductCode = @ProductCode
	END
END 
GO
CREATE PROC [dbo].[sp_DeleteProduct]
(
@ProductCode VARCHAR(100)
)
AS
BEGIN
	DELETE FROM Product WHERE ProductCode = @ProductCode
END 
GO
CREATE PROC [dbo].[sp_GetProduct]
AS
BEGIN
	SELECT * FROM Product
END 
